You can find documentation at:
http://premiumcoding.com/

Change log:

v 1.1. 23.11.2013

-fixed rich text editor add image bug
/page-builder-pmc-shortcode plugin

-fixed some color styling bugs
/style.css
/css/style_options.css
/css/options.css

-fixed menu scroll 
/js/custom.js

-added option to selecat active category for portfolio on page load
/page-builder-pmc-shortcode plugin

v 1.2.

-removed shorten function
/function.php
/includes/boxes/loopBlogLink.php
/includes/boxes/loopBlog.php

-fixed comment author bug
/comments.php