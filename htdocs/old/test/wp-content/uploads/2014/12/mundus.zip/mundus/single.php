<?php get_header(); ?>

<?php

      get_template_part('single_defult');

?>
<?php get_footer(); ?>